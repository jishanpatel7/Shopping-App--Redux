

const initState = {
    products:[],
    isLoading:false,
    isError:false
}

export const Reducer = ()=>{
    // add the switch statement for different actions
}