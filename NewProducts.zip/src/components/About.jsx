import React from 'react'

export const About = () => {
  return (
    <div>
        <h2>This is the About Page</h2>
        
    </div>
  )
}
