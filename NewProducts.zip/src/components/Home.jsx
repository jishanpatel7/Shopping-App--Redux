import React from 'react'

export const Home = () => {
  return (
    <div>
        <h2> This is the Main Page of my Website</h2>
   <div>
    <h3>This is the Home Page</h3>
   </div>
    </div>
  )
}
