
export const SingleProductList = () => {

    return (
        <div>
            <h2>Single Product</h2>
        </div>
    )
}